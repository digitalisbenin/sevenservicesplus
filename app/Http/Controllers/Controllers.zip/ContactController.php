<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class ContactController extends Controller
{
    public function send(Request $request)
    {
        
        // Valider les données du formulaire
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email',
            'message' => 'required|string',
        ]);

        // Données pour l'email
        $data = [
            'name' => $request->name,
            'email' => $request->email,
            'message' => $request->message,
        ];
       
        try {
            // Envoi de l'email
            Mail::send([], [], function ($message) use ($data) {
                $message->to('contact01.digitalis@gmail.com')
                    ->subject('Nouveau message de contact')
                    ->html("
                        <p><strong>Nom :</strong> {$data['name']}</p>
                        <p><strong>Email :</strong> {$data['email']}</p>
                        <p><strong>Message :</strong></p>
                        <p>{$data['message']}</p>
                    ");
            });
        
            // Retour avec un message de succès
            return back()->with('success', 'Votre message a été envoyé avec succès.');
        } catch (\Exception $e) {
            // En cas d'erreur, retournez un message d'échec
            return back()->with('error', 'Une erreur est survenue lors de l\'envoi de votre message.');
        }
    }
}
